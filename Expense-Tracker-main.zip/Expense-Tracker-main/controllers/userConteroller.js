const UserModel = require("../models/userModel");

const loginConteroller = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await UserModel.findOne({ email, password });
    if (!user) {
      return res.status(404).send("User not found");
    }
    res.status(200).json({ success: true, user });
  } catch (error) {
    res.status(400).json({ success: false, error });
  }
};

const registerConteroller = async (req, res) => {
  try {
    const newUser = new UserModel(req.body);
    await newUser.save();
    res.status(201).json({ success: true, newUser });
  } catch (error) {
    res.status(400).json({ success: false, error });
  }
};

module.exports = { loginConteroller, registerConteroller };
